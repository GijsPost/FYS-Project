package hva.fys;

import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.shape.*;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.text.Text;
import javafx.stage.Stage;
 
public class MenuScene {
    @FXML private Circle addLuggage;
    @FXML private Circle planeImageB;
    @FXML private Circle planeImageC;
    @FXML private Circle planeImageD;
    @FXML private Circle planeImageE;
    @FXML private Circle planeImageF;
    @FXML private Text tooltip;
    
    @FXML protected void handleLogin(ActionEvent event) {
        System.out.println("Logged In");
    }
    
    private ImagePattern image(String path) {
        return new ImagePattern(new Image(getClass().getResourceAsStream(path)));
    }
    
    @FXML protected void handleViewLogs(ActionEvent event) {
        try {
            Stage stage = Utilities.getStage(event);
            stage.setScene(Utilities.loadScene("Logs", 800, 600));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    @FXML protected void initialize() {
        addLuggage.setFill(image("LostLuggage.png"));
        planeImageB.setFill(image("FoundLuggage.png"));
        planeImageC.setFill(image("Verification.png"));
        planeImageD.setFill(image("ManualMatching.png"));
        planeImageE.setFill(image("DBIcon.png"));
        planeImageF.setFill(image("Exit.png"));
    
        addAnimationButton(addLuggage, "Add Missing Luggage", (MouseEvent ev) -> {
            try {
                Scene scene = Utilities.loadScene("AddMissing", 800, 600);
                ((Stage)tooltip.getScene().getWindow()).setScene(scene);
            } catch (Exception ex) {
                Logger.getLogger(MenuScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        addAnimationButton(planeImageB, "Add Found Luggage", (MouseEvent ev) -> {
            try {
                Scene scene = Utilities.loadScene("AddFound", 800, 600);
                ((Stage)tooltip.getScene().getWindow()).setScene(scene);
            } catch (Exception ex) {
                Logger.getLogger(MenuScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        addAnimationButton(planeImageC, "Verification", (MouseEvent ev) -> {
            try {
                Scene scene = Utilities.loadScene("Verification", 800, 600);
                ((Stage)tooltip.getScene().getWindow()).setScene(scene);
            } catch (Exception ex) {
                Logger.getLogger(MenuScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        addAnimationButton(planeImageD, "Manual Matching", (MouseEvent ev) -> {
            try {
                Scene scene = Utilities.loadScene("ManualMatch", 800, 600);
                ((Stage)tooltip.getScene().getWindow()).setScene(scene);
            } catch (Exception ex) {
                Logger.getLogger(MenuScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        addAnimationButton(planeImageE, "Browse Database", (MouseEvent ev) -> {
            try {
                Scene scene = Utilities.loadScene("DatabaseView", 800, 600);
                ((Stage)tooltip.getScene().getWindow()).setScene(scene);
            } catch (Exception ex) {
                Logger.getLogger(MenuScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        addAnimationButton(planeImageF, "Exit", (MouseEvent ev) -> {
            ((Stage)tooltip.getScene().getWindow()).close();
        });
    }

    private void addAnimationButton(Circle circle, String tooltip, EventHandler<MouseEvent> callback) {
        circle.setStrokeWidth(5);
        circle.setStroke(Color.TRANSPARENT);
        circle.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent ev) -> {
            circle.setStroke(Color.WHITE);
            this.tooltip.setText(tooltip);
        });

        circle.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent ev) -> {
            circle.setStroke(Color.TRANSPARENT);
            this.tooltip.setText("Main Menu");
        });
        
        circle.addEventHandler(MouseEvent.MOUSE_CLICKED, callback);
    }
}