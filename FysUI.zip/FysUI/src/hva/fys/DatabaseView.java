package hva.fys;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;


 
public class DatabaseView {
    @FXML private Rectangle planeImage;
    @FXML protected void handleConfirm(ActionEvent event) {
        try {
            Stage stage = Utilities.getStage(event);
            stage.setScene(Utilities.loadScene("MenuScene", 800, 600));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    } 
    @FXML protected void handleBackToMenu(ActionEvent event) {
        try {
            Stage stage = Utilities.getStage(event);
            stage.setScene(Utilities.loadScene("MenuScene", 800, 600));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    @FXML protected void initialize() {
        Image img = new Image(getClass().getResourceAsStream("DBIcon.png"));
        planeImage.setFill(new ImagePattern(img));
    }
}