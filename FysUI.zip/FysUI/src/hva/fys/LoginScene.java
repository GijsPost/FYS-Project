package hva.fys;

import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.shape.*;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;
 
public class LoginScene {
    @FXML private TextField usernameField;
    @FXML private TextField passwordField;
    @FXML private Separator usernameSeparator;
    @FXML private Separator passwordSeparator;
    @FXML private Rectangle planeImage;
    
    @FXML protected void handleLogin(ActionEvent event) {
        try {
            Stage stage = Utilities.getStage(event);
            stage.setScene(Utilities.loadScene("MenuScene", 800, 600));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    @FXML protected void initialize() {
        usernameField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
                usernameSeparator.setId("separator-active");
            else
                usernameSeparator.setId("");
        });
        
        passwordField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
                passwordSeparator.setId("separator-active");
            else
                passwordSeparator.setId("");
        });
        

        Image img = new Image(getClass().getResourceAsStream("airplane_landing.png"));
        planeImage.setFill(new ImagePattern(img));
    }

    @FXML protected void focusUsername(ActionEvent event) {
       usernameField.setId("textfield-active");
       passwordField.setId("textfield-deactive");
       System.out.println("LOGGG");
    }
    
    @FXML protected void focusPassword(ActionEvent event) {
        System.out.println("LOGGG");
    }
    
}