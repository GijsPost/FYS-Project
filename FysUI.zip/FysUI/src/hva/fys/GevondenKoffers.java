package hva.fys;
import javafx.beans.property.SimpleStringProperty;
 
public class GevondenKoffers {
   private final SimpleStringProperty ID = new SimpleStringProperty("");
   private final SimpleStringProperty Reference = new SimpleStringProperty("");
   private final SimpleStringProperty Type = new SimpleStringProperty("");

public GevondenKoffers() {
       this("", "", "");
        
    }
 
    public GevondenKoffers(String ID, String Reference, String Type) {
        setID(ID);
        setReference(Reference);
        setType(Type);
    }

    public String getID() {
        return ID.get();
    }
 
    public void setID(String fName) {
        ID.set(fName);
    }
        
    public String getReference() {
        return Reference.get();
    }
    
    public void setReference(String fName) {
        Reference.set(fName);
    }
    
    public String getType() {
        return Type.get();
    }
    
    public void setType(String fName) {
        Type.set(fName);
    }
}
