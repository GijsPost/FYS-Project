package hva.fys;

import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;
import javafx.scene.control.ScrollPane;
import javafx.scene.shape.Rectangle;

public class AddFound {
    @FXML private TextField labelField;
    @FXML private TextField kleurField;
    @FXML private TextField originAirportField;
    @FXML private TextField foundAirportField;
    
    @FXML private Separator labelSeparator;    
    @FXML private Separator kleurSeparator;
    @FXML private Separator originAirportSeparator;
    @FXML private Separator foundAirportSeparator;
    @FXML private Rectangle planeImage;
    
    @FXML protected void handleConfirm(ActionEvent event) {
        try {
            Stage stage = Utilities.getStage(event);
            stage.setScene(Utilities.loadScene("MenuScene", 800, 600));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    @FXML protected void handleBackToMenu(ActionEvent event) {
        try {
            Stage stage = Utilities.getStage(event);
            stage.setScene(Utilities.loadScene("MenuScene", 800, 600));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    
    @FXML protected void initialize() {
        labelField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
                labelSeparator.setId("separator-active");
            else
                labelSeparator.setId("");
        });
        
        kleurField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
               kleurSeparator.setId("separator-active");
            else
                kleurSeparator.setId("");
        });
        
        originAirportField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
                originAirportSeparator.setId("separator-active");
            else
                originAirportSeparator.setId("");
        });
        foundAirportField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
                foundAirportSeparator.setId("separator-active");
            else
                foundAirportSeparator.setId("");
        });
        
        Image img = new Image(getClass().getResourceAsStream("airplane_landing.png"));
        planeImage.setFill(new ImagePattern(img));
        
    }
    
}