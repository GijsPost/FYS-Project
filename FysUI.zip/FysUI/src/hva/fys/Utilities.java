/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hva.fys;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Aruna
 */
public class Utilities {
    
    public static Scene loadScene(String filename, int width, int height) throws Exception {
        Parent root = FXMLLoader.load(Utilities.class.getResource(filename + ".fxml"));
        Scene scene = new Scene(root, width, height);
        scene.getStylesheets().add(Utilities.class.getResource(filename + ".css").toExternalForm());
        return scene;
    }
    
    public static Stage getStage(ActionEvent event) {
        return (Stage)((Node)event.getSource()).getScene().getWindow();
    }
}
