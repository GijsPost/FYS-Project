package hva.fys;

import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.shape.*;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;
import javafx.scene.control.ScrollPane;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.*;

public class AddMissing {
    @FXML private TextField labelField;
    @FXML private TextField naamField;
    @FXML private TextField adresField;
    @FXML private TextField telefoonField;
    @FXML private TextField emailField;
    @FXML private TextField kleurField;
    @FXML private TextField plaatsField;
    @FXML private TextField postcodeField;
    @FXML private TextField airportField;
    
    @FXML private Separator labelSeparator;
    @FXML private Separator naamSeparator;
    @FXML private Separator adresSeparator;
    @FXML private Separator telefoonSeparator;      
    @FXML private Separator emailSeparator;
    @FXML private Separator kleurSeparator;
    @FXML private Separator plaatsSeparator;
    @FXML private Separator postcodeSeparator;
    @FXML private Separator airportSeparator;
    
    @FXML private Rectangle planeImage;
    
    @FXML protected void handleConfirm(ActionEvent event) {
        try {
            Stage stage = Utilities.getStage(event);
            stage.setScene(Utilities.loadScene("MenuScene", 800, 600));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    @FXML protected void handleBackToMenu(ActionEvent event) {
        try {
            Stage stage = Utilities.getStage(event);
            stage.setScene(Utilities.loadScene("MenuScene", 800, 600));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    @FXML protected void initialize() {
        labelField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
                labelSeparator.setId("separator-active");
            else
                labelSeparator.setId("");
        });
        
        naamField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
                naamSeparator.setId("separator-active");
            else
                naamSeparator.setId("");
        });
        
        adresField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
                adresSeparator.setId("separator-active");
            else
                adresSeparator.setId("");
        });
        
        telefoonField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
                telefoonSeparator.setId("separator-active");
            else
                telefoonSeparator.setId("");
        });
        
        emailField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
               emailSeparator.setId("separator-active");
            else
                emailSeparator.setId("");
        });
        
        kleurField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
               kleurSeparator.setId("separator-active");
            else
                kleurSeparator.setId("");
        });
        
        plaatsField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
               plaatsSeparator.setId("separator-active");
            else
               plaatsSeparator.setId("");
        });

        postcodeField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
                postcodeSeparator.setId("separator-active");
            else
                postcodeSeparator.setId("");
        });
        
        airportField.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean prev, Boolean value) -> {
            if (value)
                airportSeparator.setId("separator-active");
            else
                airportSeparator.setId("");
        });
        
        Image img = new Image(getClass().getResourceAsStream("airplane_landing.png"));
        planeImage.setFill(new ImagePattern(img));
        
    }
    
}