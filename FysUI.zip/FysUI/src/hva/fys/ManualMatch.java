package hva.fys;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.scene.chart.*;
import javafx.scene.Group;


 
public class ManualMatch extends Application {
    
    @FXML private Rectangle planeImage;
    
    @FXML protected void handleConfirm(ActionEvent event) {
        try {
            Stage stage = Utilities.getStage(event);
            stage.setScene(Utilities.loadScene("MenuScene", 800, 600));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    } 
    @FXML protected void handleBackToMenu(ActionEvent event) {
        try {
            Stage stage = Utilities.getStage(event);
            stage.setScene(Utilities.loadScene("MenuScene", 800, 600));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    @FXML protected void handleRefresh(ActionEvent event) {
        try {
        
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    @FXML protected void initialize() {
        Image img = new Image(getClass().getResourceAsStream("DBIcon.png"));
        planeImage.setFill(new ImagePattern(img));
    }
    

    @Override
    public void start(Stage primaryStage) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}